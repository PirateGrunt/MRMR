MRMR
====

Multivariate Regression Model for Reserving

MRMR has code to support analysis of property/casualty loss reserves and visual presentation of liability data. The focus is on the use of linear models (generalized and OLS) for modeling. At a future date, we expect to add support for database I/O for sample data and model results.